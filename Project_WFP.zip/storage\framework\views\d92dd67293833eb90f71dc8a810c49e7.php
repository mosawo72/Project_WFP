<?php $__env->startSection('title', 'Data Dokter - VitaGuard'); ?>
<?php $__env->startSection('page-title', 'Master Data Dokter'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h4><i class="fas fa-user-md me-2" style="color: var(--secondary);"></i>Data Dokter</h4>
    <p>Daftar dokter yang tersedia di VitaGuard</p>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6><i class="fas fa-table me-2"></i>Tabel Dokter</h6>
        <span class="badge bg-primary rounded-pill"><?php echo e($doctors->count()); ?> data</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table" id="doctors-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Dokter</th>
                        <th>Spesialisasi</th>
                        <th>Pengalaman</th>
                        <th>Bio</th>
                        <th>Jadwal Praktik</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div style="width:32px;height:32px;font-size:0.7rem;border-radius:50%;background:linear-gradient(135deg,#6366f1,#4f46e5);color:white;display:flex;align-items:center;justify-content:center;font-weight:600;">
                                    <?php echo e(strtoupper(substr($doctor->user->name, 0, 1))); ?>

                                </div>
                                <strong><?php echo e($doctor->user->name); ?></strong>
                            </div>
                        </td>
                        <td>
                            <span class="badge bg-light text-dark border"><?php echo e($doctor->specialization); ?></span>
                        </td>
                        <td><?php echo e($doctor->experience_years); ?> tahun</td>
                        <td><?php echo e(Str::limit($doctor->bio, 50)); ?></td>
                        <td><small class="text-muted"><?php echo e($doctor->schedule); ?></small></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_WFP\resources\views/master/doctors.blade.php ENDPATH**/ ?>