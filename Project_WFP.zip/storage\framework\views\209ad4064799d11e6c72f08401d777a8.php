<?php $__env->startSection('title', 'Data Users - VitaGuard'); ?>
<?php $__env->startSection('page-title', 'Master Data Users'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h4><i class="fas fa-users me-2" style="color: var(--primary);"></i>Data Users</h4>
    <p>Daftar semua pengguna yang terdaftar di VitaGuard</p>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6><i class="fas fa-table me-2"></i>Tabel Users</h6>
        <span class="badge bg-primary rounded-pill"><?php echo e($users->count()); ?> data</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table" id="users-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Telepon</th>
                        <th>Alamat</th>
                        <th>Terdaftar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="avatar" style="width:32px;height:32px;font-size:0.7rem;border-radius:50%;background:linear-gradient(135deg,#0d9488,#6366f1);color:white;display:flex;align-items:center;justify-content:center;font-weight:600;">
                                    <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                                </div>
                                <strong><?php echo e($user->name); ?></strong>
                            </div>
                        </td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                            <span class="badge-role badge-<?php echo e($user->role); ?>">
                                <?php echo e(ucfirst($user->role)); ?>

                            </span>
                        </td>
                        <td><?php echo e($user->phone ?? '-'); ?></td>
                        <td><?php echo e(Str::limit($user->address, 30) ?? '-'); ?></td>
                        <td><?php echo e($user->created_at->format('d M Y')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_WFP\resources\views/master/users.blade.php ENDPATH**/ ?>