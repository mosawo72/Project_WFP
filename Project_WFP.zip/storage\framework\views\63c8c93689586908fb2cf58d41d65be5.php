<?php $__env->startSection('title', 'Data Artikel - VitaGuard'); ?>
<?php $__env->startSection('page-title', 'Master Data Artikel'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h4><i class="fas fa-newspaper me-2" style="color: var(--accent);"></i>Data Artikel Kesehatan</h4>
    <p>Daftar artikel kesehatan di VitaGuard</p>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6><i class="fas fa-table me-2"></i>Tabel Artikel</h6>
        <span class="badge bg-primary rounded-pill"><?php echo e($articles->count()); ?> data</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table" id="articles-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Judul</th>
                        <th>Kategori</th>
                        <th>Penulis</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><strong><?php echo e(Str::limit($article->title, 40)); ?></strong></td>
                        <td>
                            <span class="badge bg-light text-dark border"><?php echo e($article->category); ?></span>
                        </td>
                        <td><?php echo e($article->user->name); ?></td>
                        <td>
                            <span class="badge-status badge-<?php echo e($article->status); ?>">
                                <?php echo e(ucfirst($article->status)); ?>

                            </span>
                        </td>
                        <td><?php echo e($article->created_at->format('d M Y')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_WFP\resources\views/master/articles.blade.php ENDPATH**/ ?>