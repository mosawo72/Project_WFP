<?php $__env->startSection('title', 'Data Konsultasi - VitaGuard'); ?>
<?php $__env->startSection('page-title', 'Master Data Konsultasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h4><i class="fas fa-comments me-2" style="color: #06b6d4;"></i>Data Konsultasi</h4>
    <p>Daftar konsultasi online di VitaGuard</p>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6><i class="fas fa-table me-2"></i>Tabel Konsultasi</h6>
        <span class="badge bg-primary rounded-pill"><?php echo e($consultations->count()); ?> data</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table" id="consultations-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Member</th>
                        <th>Dokter</th>
                        <th>Subjek</th>
                        <th>Status</th>
                        <th>Jadwal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $consultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $consultation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($consultation->member->name); ?></td>
                        <td>
                            <div>
                                <strong><?php echo e($consultation->doctor->user->name); ?></strong>
                                <br><small class="text-muted"><?php echo e($consultation->doctor->specialization); ?></small>
                            </div>
                        </td>
                        <td><?php echo e(Str::limit($consultation->subject, 35)); ?></td>
                        <td>
                            <span class="badge-status badge-<?php echo e($consultation->status); ?>">
                                <?php echo e(ucfirst($consultation->status)); ?>

                            </span>
                        </td>
                        <td>
                            <?php if($consultation->scheduled_at): ?>
                                <?php echo e($consultation->scheduled_at->format('d M Y')); ?>

                                <br><small class="text-muted"><?php echo e($consultation->scheduled_at->format('H:i')); ?> WIB</small>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_WFP\resources\views/master/consultations.blade.php ENDPATH**/ ?>