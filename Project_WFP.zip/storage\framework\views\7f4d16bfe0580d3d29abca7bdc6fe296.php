<?php $__env->startSection('title', 'Tambah User - VitaGuard'); ?>
<?php $__env->startSection('page-title', 'Tambah User Baru'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h4><i class="fas fa-user-plus me-2" style="color: var(--primary);"></i>Tambah User Baru</h4>
    <p>Isi form di bawah untuk menambahkan user baru</p>
</div>

<div class="card">
    <div class="card-body">
        <form action="<?php echo e(route('users.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="name" class="form-label fw-semibold">Nama Lengkap <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="email" class="form-label fw-semibold">Email <span class="text-danger">*</span></label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="password" class="form-label fw-semibold">Password <span class="text-danger">*</span></label>
                    <input type="password" class="form-control" id="password" name="password" required minlength="6">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="role" class="form-label fw-semibold">Role <span class="text-danger">*</span></label>
                    <select class="form-select" id="role" name="role" required>
                        <option value="">-- Pilih Role --</option>
                        <option value="admin" <?php echo e(old('role') == 'admin' ? 'selected' : ''); ?>>Admin</option>
                        <option value="dokter" <?php echo e(old('role') == 'dokter' ? 'selected' : ''); ?>>Dokter</option>
                        <option value="member" <?php echo e(old('role') == 'member' ? 'selected' : ''); ?>>Member</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="phone" class="form-label fw-semibold">Telepon</label>
                    <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e(old('phone')); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="address" class="form-label fw-semibold">Alamat</label>
                    <textarea class="form-control" id="address" name="address" rows="2"><?php echo e(old('address')); ?></textarea>
                </div>
            </div>
            <div class="d-flex gap-2 mt-2">
                <button type="submit" class="btn btn-primary" style="background: linear-gradient(135deg, var(--primary), var(--primary-dark)); border: none; border-radius: 8px;">
                    <i class="fas fa-save me-1"></i> Simpan
                </button>
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary" style="border-radius: 8px;">
                    <i class="fas fa-arrow-left me-1"></i> Kembali
                </a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_WFP\resources\views/master/users/create.blade.php ENDPATH**/ ?>