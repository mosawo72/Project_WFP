<?php $__env->startSection('title', 'Data Booking - VitaGuard'); ?>
<?php $__env->startSection('page-title', 'Master Data Booking'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header d-flex justify-content-between align-items-start">
    <div>
        <h4><i class="fas fa-calendar-check me-2" style="color: #ef4444;"></i>Data Booking Konsultasi</h4>
        <p>Daftar booking konsultasi di VitaGuard</p>
    </div>
    <a href="<?php echo e(route('bookings.create')); ?>" class="btn btn-primary" style="background: linear-gradient(135deg, #ef4444, #dc2626); border: none; border-radius: 8px;">
        <i class="fas fa-plus me-1"></i> Tambah Booking
    </a>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6><i class="fas fa-table me-2"></i>Tabel Booking</h6>
        <span class="badge bg-primary rounded-pill"><?php echo e($bookings->count()); ?> data</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table" id="bookings-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Member</th>
                        <th>Dokter</th>
                        <th>Tanggal</th>
                        <th>Jam</th>
                        <th>Status</th>
                        <th>Catatan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($booking->member->name); ?></td>
                        <td>
                            <strong><?php echo e($booking->doctor->user->name); ?></strong>
                            <br><small class="text-muted"><?php echo e($booking->doctor->specialization); ?></small>
                        </td>
                        <td><?php echo e($booking->booking_date->format('d M Y')); ?></td>
                        <td><?php echo e($booking->booking_time); ?></td>
                        <td><span class="badge-status badge-<?php echo e($booking->status); ?>"><?php echo e(ucfirst($booking->status)); ?></span></td>
                        <td><?php echo e(Str::limit($booking->notes, 25) ?? '-'); ?></td>
                        <td>
                            <div class="d-flex gap-1">
                                <a href="<?php echo e(route('bookings.show', $booking)); ?>" class="btn btn-sm btn-outline-info" title="Detail"><i class="fas fa-eye"></i></a>
                                <a href="<?php echo e(route('bookings.edit', $booking)); ?>" class="btn btn-sm btn-outline-warning" title="Edit"><i class="fas fa-edit"></i></a>
                                <form action="<?php echo e(route('bookings.destroy', $booking)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus booking ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Hapus"><i class="fas fa-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_WFP\resources\views/master/bookings/index.blade.php ENDPATH**/ ?>